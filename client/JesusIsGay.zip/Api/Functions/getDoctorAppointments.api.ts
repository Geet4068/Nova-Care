
import { AppointmentResponse } from "@/Interface/appointment.interface";
import axiosInstance from "../Axios/Axios";
import { endpoints } from "../Endpoints/Endpoints";


export const GetDoctorAppointments = async (): Promise<AppointmentResponse> => {
    try {

        const response = await axiosInstance.get<AppointmentResponse>(endpoints.appointment.getDoctorAppointments);

        // console.log("Doctor Appointment List Response:", response.data);
        return response.data;

    } catch (error) {
        console.error("Error fetching your Appointment:", error);
        return {
            status: 500,
            message: "Failed to fetch your Appointment",
        };
    }
}